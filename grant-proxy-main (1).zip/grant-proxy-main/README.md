# grant-proxy
A web proxy I edited...
# Use
```npm install```
then
```npm start```
done!
